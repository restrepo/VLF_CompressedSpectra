/*
-------     Universidad de los Andes      -------
-------      Departamento de Física       -------
-------   Proyecto Joven Investigador     -------
-------  Andrés Felipe García Albarracín  -------
-------    Juan Carlos Sanabria Arenas    -------

HepMC .h files
*/

#include "HepMC/GenEvent.h"
#include "HepMC/GenParticle.h"
#include "HepMC/GenVertex.h"
#include "HepMC/IO_GenEvent.h"
