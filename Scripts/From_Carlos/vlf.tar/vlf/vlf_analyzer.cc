#include "vlf_analyzer.h"

using namespace std;

// Global variables
double pi = 4.0*atan(1.0);

// begining of the program
int main(int argc, char *argv[]) {
  
  // Open Tchain inside Delphes
  TChain chain("Delphes");
  chain.Add(argv[1]);    
  
  // Create object of class ExRootTreeReader
  ExRootTreeReader *treeReader = new ExRootTreeReader(&chain);
  
  // Number of entries access
  long int numberOfEntries = treeReader->GetEntries();
  
  // Get pointers to branches used in this analysis 
  TClonesArray *branchJet = treeReader->UseBranch("Jet");
  TClonesArray *branchMuon = treeReader->UseBranch("Muon");
  TClonesArray *branchMissingET = treeReader->UseBranch("MissingET");

 //Histograms
  TH1 *histNumjets = new TH1F("num_jets","num_jets",10, 0.0, 10.0);
  TH1 *histPT_jets = new TH1F("pt_jet","pt_jet",100, 0.0, 400.0);
  TH1 *histEta_jets = new TH1F("eta_jet","eta_jet",100, -5.0, 5.0);
  TH1 *histNumMuons = new TH1F("num_muons","num_muons",10,0.0,10.0);
  TH1 *histPT_muons = new TH1F("pt_muon","pt_muon",100, 0.0, 100.0);
  TH1 *histEta_muons = new TH1F("eta_muon","eta_muon",100, -5.0, 5.0);
  TH1 *histmet = new TH1F("met","met",100, 0.0, 350.0);
  TH1F *hbtags = new TH1F("nbtags","nbtags",5, 0.0, 5.0);
 //delta_phi histograms
  
  TH1F *histdeltaphi_mu_jet = new TH1F("dphi_mu_jet","dphi_mu_jet",100, 0.0, 6.5);
  TH1F *histdeltaphi_mu_met = new TH1F("dphi_mu_met","dphi_mu_met",100, 0.0, 6.5);
  TH1F *histdeltaphi_jet_met = new TH1F("dphi_jet_met","dphi_jet_met",100, 0.0, 6.5);
  //ratio of PT histograms
  TH1F *histR_mu_met = new TH1F("r_mu_met","r_mu_met",100, 0.0, 5.0);
  TH1F *histR_jet_met = new TH1F("r_jet_met","r_jet_met",100, 0.0, 5.0);
  TH1F *histR_mu_jet = new TH1F("r_mu_jet","r_mu_jet",100, 0.0, 1.0);
  // MT histograms
   TH1F *hist_mt_mumet = new TH1F("mt_mumet","mt_mumet",100, 0.0, 300.0);
   TH1F *hist_mt_jetmet = new TH1F("mt_jetmet","mt_jetmet",100, 0.0, 1000.0);
   TH1F *hist_mt_mujet = new TH1F("mt_mujet","mt_mujet",100, 0.0, 300.0);
   TH1F *hist_ht = new TH1F("ht","ht",100, 0.0, 500.0);
  
  // Loop over all events
  
  for ( Int_t entry = 0; entry < numberOfEntries; ++entry ){
    
    // Load selected branches with data from specified event
    treeReader->ReadEntry(entry);
    int Numjets = branchJet->GetEntries();  
    histNumjets->Fill(Numjets);
    int NumMuons = branchMuon->GetEntries();
    histNumMuons->Fill(NumMuons);
    
    //Creating pointer for each particle
    MissingET *metpointer;
    Muon *muonpointer;
    Jet *jeti;
    metpointer = (MissingET*)branchMissingET->At(0);
    muonpointer = (Muon*)branchMuon->At(0);
    int nbtags=0;
 //verify that there are muons    
    if(NumMuons>0){
      histPT_muons->Fill(muonpointer->PT);
      histEta_muons->Fill(muonpointer->Eta);
      histmet->Fill(metpointer->MET);
       if (Numjets<0) continue; // Verify that there are jets in the event
      //Start loop over jets
      double ht=0.0;
      double mt_mumet,mt_jetmet,mt_mujet,rmumet,rjetmet,rmujet;
      double dphi_mujet, dphi_mumet,dphi_jetmet;
      dphi_mumet=fabs(muonpointer->Phi-metpointer->Phi);
      mt_mumet=sqrt(2*muonpointer->PT*metpointer->MET*(1-cos(dphi_mumet)));
      if (metpointer->MET>0) rmumet=muonpointer->PT/metpointer->MET;
      for(Int_t i = 0; i < Numjets; i++){
	jeti = (Jet*) branchJet->At(i);
	histPT_jets->Fill(jeti->PT);
	histEta_jets->Fill(jeti->Eta);
	ht+=jeti->PT;
	if (jeti->BTag>0) nbtags++; 
	if (i==0) {  // leading jet condition
	  dphi_mujet=fabs(muonpointer->Phi-jeti->Phi);

	  dphi_jetmet=fabs(jeti->Phi-metpointer->Phi);
	  mt_mujet=sqrt(2*muonpointer->PT*jeti->PT*(1-cos(dphi_mujet)));
	  mt_jetmet=sqrt(2*jeti->PT*metpointer->MET*(1-cos(dphi_jetmet)));
	  if (metpointer->MET>0) rjetmet=jeti->PT/metpointer->MET;
	  if (jeti->PT>0) rmujet=muonpointer->PT/jeti->PT;
	}
	
      }//end loop over jets
      hist_ht->Fill(ht);
      hbtags->Fill(nbtags);     
      histdeltaphi_mu_jet->Fill(dphi_mujet);
      histdeltaphi_mu_met->Fill(dphi_mumet);
      histdeltaphi_jet_met->Fill(dphi_jetmet);
      
      histR_mu_met->Fill(rmumet);
      histR_mu_jet->Fill(rmujet);
      histR_jet_met->Fill(rjetmet);
      
      hist_mt_mumet->Fill(mt_mumet);
      hist_mt_mujet->Fill(mt_mujet);
      hist_mt_jetmet->Fill(mt_jetmet);
    } //end if over NumMuons
  } //end loop over entries
  
  // ROOT Program output
  TFile* hfile = new TFile(argv[2], "RECREATE");
  histNumjets->Write();
  histNumMuons->Write();
  histPT_jets->Write();
  histEta_jets->Write();
  histPT_muons->Write();
  histEta_muons->Write();
  histmet->Write();
  hbtags->Write();
  hist_ht->Write();
  
  histdeltaphi_mu_jet->Write();
  histdeltaphi_mu_met->Write();
  histdeltaphi_jet_met->Write();
  
  histR_mu_met->Write();
  histR_mu_jet->Write();
  histR_jet_met->Write();
  
  hist_mt_mumet->Write();
  hist_mt_mujet->Write();
  hist_mt_jetmet->Write();

  hfile->Close();
  
} //end program


    


 


 





   

