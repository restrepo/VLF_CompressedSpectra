{
  // Initialize root
  gROOT->Reset();
  gROOT->SetStyle("Plain");
  gStyle->SetOptStat(0);
  gStyle->SetOptFit(0);

  //Define canvas for plotting
  TCanvas *c1;
  TCanvas *c2;
  c1 =new TCanvas("muon","muon",900,600);
  c2=new TCanvas("jet","jet",900,600);

  c1->Divide(3,3);
  c2->Divide(3,3);

  // Open root file with histograms
  TFile *f1=new TFile("signal_nocuts.root");


  TString hname1[18]={"pt_muon","pt_jet","eta_muon","eta_jet","met","ht","num_jets","num_muons","nbtags","dphi_mu_jet","dphi_mu_met","dphi_jet_met","r_mu_met","r_jet_met","r_mu_jet","mt_mumet","mt_jetmet","mt_mujet"};


  TString xname1[18]={"PT_mu (GeV)","PT_jet (GeV)","eta_mu","eta_jet ","MET (GeV)","HT (GeV)",
		      "njets","nmuons","nbtags","#Delta#phi_{#mu-jet}","#Delta#phi_{#mu-MET}",
                      "#Delta#phi_{jet-MET}","PT_{#mu}/MET","PT_{jet}/MET","PT_{#mu}/PT_{j}",
                      "MT_{#mu,MET} (GeV)","MT_{jet,MET} (GeV)","MT_{#mu-jet} (GeV)"};

  // Get histograms from root file and plot
  
  for (int i=0; i<18;i++){
     TH1F *h = (TH1F *)f1->Get(hname1[i]);

     cout<<"reading histogram "<<i<<"  "<<endl;
     
     h->SetLineWidth(2);
     h->SetTitle("");
     h->SetMarkerColor(4);
     h->SetFillColor(0);
     h->SetTitle(hname1[i]);
     h->SetLineColor(4);
     
     h->SetTitleOffset(0.9,"X");
     h->SetTitleOffset(0.9,"Y");
     h->GetYaxis()->SetTitleSize(0.05);
     h->GetXaxis()->SetTitleSize(0.05);
     h->GetYaxis()->SetTitle("Normalized to unity");
     h->GetXaxis()->SetTitle(xname1[i]);
     h->GetXaxis()->CenterTitle();
     h->GetYaxis()->CenterTitle();
     h->SetMarkerStyle(20);
     h->SetMarkerSize(0.7);


     double normal=h->Integral();
     if (normal>0) normal=1.0/normal;
     h->Scale(normal);
     
     if (i<9) c1->cd(i+1);
     if (i>8) c2->cd(i-8);
     h->Draw();
  }
  c1->Modified();
  c1->Print("signal1.pdf");
  c2->Modified();
  c2->Print("signal2.pdf");

}

      
     
     
